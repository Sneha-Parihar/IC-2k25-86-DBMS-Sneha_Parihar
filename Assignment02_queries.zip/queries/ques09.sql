select count(*) from employees;
