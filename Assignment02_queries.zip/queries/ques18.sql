select * from employees limit 10;
