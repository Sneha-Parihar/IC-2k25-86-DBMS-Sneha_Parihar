select substr(first_name,1,3) from employees;
